package com.example.lifeassistant.activity.file;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.MainActivity;
import com.example.lifeassistant.dao.MemoDao;
import com.example.lifeassistant.model.Tb_Memo;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class FileManager extends AppCompatActivity implements AdapterView.OnItemClickListener, SearchView.OnQueryTextListener, AdapterView.OnItemLongClickListener {

    ListView listView;
    List<FileInfo> list;
    FileAdapter adapter;
    TextView tv_path;
    TextView tv_info;

    LinearLayout fileinput;

    String currPath;   // 当前目录
    String parentPath; // 上级目录

    final String ROOT = FileUtils.getSDCardPath(); //SDCard根目录

    public static final int T_DIR = 0;// 文件夹
    public static final int T_FILE = 1;// 文件
    public static final int T_PIC = 2;// 文件:图片
    public static final int T_VIDEO = 3;// 文件:视频


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //设置全局配置
        //ImageLoaderConfiguration 针对图片缓存的全局配置
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(this)
                .threadPriority(Thread.NORM_PRIORITY - 2)// 线程的优先级别
                .denyCacheImageMultipleSizesInMemory() // 拒绝不同的缓存大小
                .diskCacheFileNameGenerator(new Md5FileNameGenerator())// 对临时文件名加密
                .diskCacheSize(50 * 1024 * 1024) // 50 Mb SDCard上的缓存空间
                .tasksProcessingOrder(QueueProcessingType.LIFO)// 任务队列采取LIFO
                .writeDebugLogs() //调试日志-可在项目发布时删除
                .build();// 构建配置
        //ImageLoader是具体下载图片，缓存图片，显示图片的具体执行类
        ImageLoader.getInstance().init(config);// 加载全局配置

        super.onCreate(savedInstanceState);
        setContentView(R.layout.file_manager);
        //设置窗体始终点亮
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        initView();// 初始化
        updateData(ROOT);

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    /*初始化*/
    private void initView() {
        tv_path = (TextView) findViewById(R.id.fm_path);
        tv_info = (TextView) findViewById(R.id.fm_info);
        listView = (ListView) findViewById(R.id.fm_list);
        adapter = new FileAdapter(this);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);//单击
        listView.setOnItemLongClickListener(this);
    }


    /*获取目录，查看*/
    private void updateData(String path) {
        currPath = path;// 记录当前的目录（字符串）
        File file = new File(path);//当前目录的对象，
        parentPath = file.getParent();// 获取了当前目录的父路径，更新了上级目录

        list = FileUtils.getListData(path);// 数据

        //目录为空时
        tv_info.setVisibility(View.GONE);// 不可见
        if (list.size() == 0) {
            Toast.makeText(this, "当前目录为空", Toast.LENGTH_SHORT).show();
            tv_info.setVisibility(View.VISIBLE);// 恢复可见
        }
        // 排序
        list = getGroupList(list);

        adapter.setList(list);
        adapter.notifyDataSetChanged();// 刷新视图
        tv_path.setText(path);//顶端显示路径
    }

    /* 文件名的比较器，按文件名称排序*/
    Comparator<FileInfo> nameComparator = new Comparator<FileInfo>() {
        @Override
        public int compare(FileInfo lhs, FileInfo rhs) {
            //compareTo()比较对应字符的大小(ASCII码顺序)
            return lhs.name.toLowerCase().compareTo(rhs.name.toLowerCase());
        }
    };

    /**
     * 分组排序
     *
     * @param list
     * @return
     */
    public List<FileInfo> getGroupList(List<FileInfo> list) {
        //1. 文件和文件夹分为两个集合
        List<FileInfo> dirs = new ArrayList<FileInfo>();// 文件夹
        List<FileInfo> files = new ArrayList<FileInfo>();// 文件
        for (FileInfo item : list) {
            if (item.type == T_DIR) {
                dirs.add(item);
            } else {
                files.add(item);
            }
        }
        //2. 对两个集合分别排序
        Collections.sort(dirs, nameComparator);
        Collections.sort(files, nameComparator);
        //3. 集合合并:把文件集合添加到文件夹的结尾处
        dirs.addAll(files);
        return dirs;
    }


    /*
    【标题栏设置】
     */
    SearchView sv;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.file_menu_main, menu);
        //设置搜索框
        MenuItem miSearch = menu.findItem(R.id.fmm_btn_search);
        miSearch.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                // 展开
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                // 折叠
                updateData(currPath);// 更新数据
                return true;
            }
        });
        //搜索框
        sv = (SearchView) miSearch.getActionView();
        sv.setSubmitButtonEnabled(true);// 显示按钮
        sv.setOnQueryTextListener(this);// 点击"提交按钮"事件

        return true;
    }

    /*
    【新建文件夹】
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(FileManager.this,MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.fmm_build:
                enterName();
                break;
        }
        return super.onOptionsItemSelected(item);

    }

    /*
    新建目录时输入名字
     */
    private void enterName() {
        fileinput = (LinearLayout) getLayoutInflater().inflate(R.layout.file_input, null);

        new AlertDialog.Builder(this)
                .setMessage("文件夹名称")
                .setView(fileinput)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        inputClick();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void inputClick() {
        String path = tv_path.getText().toString();
        EditText name = (EditText) fileinput.findViewById(R.id.f_input);

        addFolder(path, name.getText().toString());
        updateData(path);
    }

    /*【创建一个新的文件夹】*/
    public static void addFolder(String path, String folderName) {
        try {
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                File newFolder = new File(path + File.separator + folderName);
                if (!newFolder.exists()) {
                    boolean isSuccess = newFolder.mkdirs();
                    Log.i("TAG:", "文件夹创建状态--->" + isSuccess);
                }
                Log.i("TAG:", "文件夹所在目录：" + newFolder.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /*
    【点击进入文件夹】
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        FileInfo item = (FileInfo) parent.getItemAtPosition(position);
        // 判断文件/文件夹
        if (item.type == T_DIR) {
            // 进入文件夹
            updateData(item.path);
        } else {
            // 选择合适的应用打开文件
            FileUtils.openFile(this, new File(item.path));
        }

    }

    //长按删除
    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        FileInfo item = (FileInfo) parent.getItemAtPosition(position);
        showDeleteDialog(item);
        return true;
    }


    /**
     * 弹出是否删除某一条记录的对话框
     */
    private void showDeleteDialog(final FileInfo item) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("提示信息").setMessage("您确定要删除这条记录么？")
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        File file   = new File(item.path);
                        file.delete();//删除
                        updateData(currPath);
                        Toast.makeText(FileManager.this, "成功删除", Toast.LENGTH_SHORT).show();
                    }
                });
        builder.create().show();   //显示对话框
    }

    /*
    【点击"返回"键】
     */
    @Override
    public void onBackPressed() {

        if (currPath.equals(ROOT)){ // 如果当前目录为根目录ROOT：/storage/emulated/0
            this.finish();
        }else {
            //返回上级目录
            updateData(parentPath);
        }
    }


    /* 1.声明进度框对象*/
    ProgressDialog pd;
    //显示一个环形进度框
    public void showProgressDialog() {
        pd = new ProgressDialog(FileManager.this);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setTitle("刷新列表");
        pd.setMessage("请耐心等待");
        pd.show();
    }
    /* 2.声明handler对象,处理子线程结束后,UI主线程的更新*/
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                adapter.setList(list);
                adapter.notifyDataSetChanged();
                pd.dismiss();// 关闭进度框
            }
        }
    };
    /* 3.子线程*/
    private void updateData() {
        // 启动新线程,处理耗时操作
        new Thread() {
            public void run() {

                FileUtils.getSearchList(currPath,KEYWORD,list);// 递归 //耗时操作
                handler.sendEmptyMessage(1);
            }
        }.start();
        showProgressDialog();// 显示进度框
    }

    public static String KEYWORD;
    @Override
    public boolean onQueryTextSubmit(String query) {

        list = new ArrayList<FileInfo>();
        KEYWORD = query;
        updateData();// 搜索
        return true;
    }
    @Override
    public boolean onQueryTextChange(String newText) { return true; }

}
package com.example.lifeassistant.activity.file;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.ThumbnailUtils;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lifeassistant.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.List;

public class FileAdapter extends BaseAdapter {

    //自定义数据集与布局加载器
    List<FileInfo> list;//FileInfo.java文件
    //LayoutInflater 的作用就是将XML布局文件实例化为相应的 View 对象
    LayoutInflater inflater;
    
    DisplayImageOptions options;/**/


    public FileAdapter(Context context) {

        this.inflater = LayoutInflater.from(context);

        /**/
         //图片的显示设置(选项)
        options = new DisplayImageOptions.Builder()
                .showImageForEmptyUri(R.drawable.ic_launcher)// 设置图片Uri为空或是错误的时候显示的图片
                .showImageOnFail(R.drawable.ic_launcher)/// 设置图片加载/解码过程中错误时候显示的图片
                .cacheInMemory(true)// 设置下载的图片是否缓存在内存中
                .cacheOnDisk(true)// 设置下载的图片是否缓存在SD卡中
                // 设置图片以如何的编码方式显示\EXACTLY :图像将完全按比例缩小的目标大小
                .imageScaleType(ImageScaleType.EXACTLY)
                .bitmapConfig(Bitmap.Config.RGB_565)//图片的解码类型
                .considerExifParams(true)//是否考虑JPEG图像EXIF参数（旋转，翻转）
                .build();// 构建完成
    }

    public void setList(List<FileInfo> list) {
        this.list = list;
    }

    @Override
    public int getCount() {
        return (list == null)?0:list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /*
    int position:位置,判断当前显示的项目在屏幕上的位置，然后通过position在定义的集合中取值显示在屏幕上
    View convertView:转换 视图,缓存被滚动到界面之外的项目，提高效率
    ViewGroup parent:父本,存放被加载出来的每一个项目视图
    */
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;//ViewHolder:包含列表项的控件

        // 如果view未被实例化过，缓存池中没有对应的缓存 则进行加载
        if(convertView == null) {
            //由于我们只需要将XML转化为View，并不涉及到具体的布局，所以第二个参数通常设置为null
            convertView = inflater.inflate(R.layout.file_item, null);
            holder = new ViewHolder();// 初始化 ViewHolder 方便重用

            holder.icon = (ImageView) convertView.findViewById(R.id.fi_icon);
            holder.play = (ImageView) convertView.findViewById(R.id.fi_play);
            holder.name = (TextView) convertView.findViewById(R.id.fi_name);
            holder.size = (TextView) convertView.findViewById(R.id.fi_desc);
            holder.path = (TextView) convertView.findViewById(R.id.fi_path);
            //通过setTag将convertView与holder关联
            convertView.setTag(holder);
        }else{
            //如果缓存池中有对应的view缓存，则直接通过getTag取出holder
            holder = (ViewHolder) convertView.getTag();
        }
        FileInfo item = list.get(position);// 获得item内容对象

        /**/
        // 显示图标
        if(item.type == FileManager.T_PIC){// 文件类型--- 图片:缩略图
            String path = item.path;

            String uri = "file://" + path;
            ImageLoader.getInstance().displayImage(uri,holder.icon,options,
                    new SimpleImageLoadingListener(){

                        @Override
                        public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                            // 加载中
                        }
                        @Override
                        public void onLoadingCancelled(String imageUri, View view) {
                            // 取消
                        }
                        @Override
                        public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                            // 加载失败
                        }
                        @Override
                        public void onLoadingStarted(String imageUri, View view) {
                            // 加载开始
                        }
                    });
        }else if(item.type == FileManager.T_VIDEO) {// 视频
            // 生成缩略图 Thumbnails.MICRO_KIND(最小的缩略图)
            Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(item.path,
                    MediaStore.Video.Thumbnails.MICRO_KIND);

            holder.icon.setImageBitmap(bitmap);// 设定ImageView的Bitmap
            holder.play.setVisibility(View.VISIBLE);// 可见
        }else{
            holder.icon.setImageResource(item.icon);// 图标
        }

         //高亮关键字
        String key = FileManager.KEYWORD;
        if (key != null && !key.equals("") ) {
            int start = item.name.toLowerCase().indexOf(key.toLowerCase());//
            int end = start + key.length();
            // 标题
            SpannableStringBuilder style = new SpannableStringBuilder(item.name);
            style.setSpan(
                    new ForegroundColorSpan(Color.RED),// 前景样式
                    start,// 起始坐标
                    end,// 终止坐标
                    Spannable.SPAN_EXCLUSIVE_INCLUSIVE// 旗标
            );
            holder.name.setText(style);//将样式应用到标题上
        }else{
            holder.name.setText(item.name);
        }

//        holder.path.setText(activity_main_item.path);
        holder.size.setText(item.size + " " + item.time);

        return convertView;
    }

    // ViewHolder用于缓存控件，5个属性分别对应item布局文件的5个控件
    public class ViewHolder{
        ImageView icon;
        ImageView play;
        TextView name;
        TextView size;
        TextView path;
    }
}

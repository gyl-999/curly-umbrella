package com.example.lifeassistant.activity.file;

/**
 * 文件的实体类
 */
public class FileInfo {

    public int icon;   //文件图标
    public String name;//文件名字
    public String size;//文件大小
    public String time;//文件时间
    public String path;//文件路径
    public int type;   // 文件类型

}

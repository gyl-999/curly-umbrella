package com.example.lifeassistant.activity;



import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.account.Account;
import com.example.lifeassistant.activity.file.FileManager;
import com.example.lifeassistant.activity.memo.Memo;
import com.example.lifeassistant.activity.schedule.Schedule;
import com.example.lifeassistant.dao.AccountDao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private GridView gview;                 //GridView:网格视图--多行多列网状形式
    private List<Map<String, Object>> data_list;
    private SimpleAdapter sim_adapter;      // SimpleAdapter适配器
    // 图片封装为一个数组
    private int[] icon = {R.drawable.memo, R.drawable.file, R.drawable.schedule,
            R.drawable.account, R.drawable.personal,R.drawable.back};
    //定义字符串数组，存储系统功能
    private String[] iconName = { "备忘录", "文件管理", "日程安排", "记账本", "个人中心", "退出登录"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gview = (GridView) findViewById(R.id.gview);
        //新建List
        data_list = new ArrayList<Map<String, Object>>();
        //获取数据
        getData();
        //新建适配器
        String [] from ={"image","text"};
        int [] to = {R.id.item_image,R.id.item_text};
        //activity_main_item.xml布局
        sim_adapter = new SimpleAdapter(this, data_list, R.layout.activity_main_item, from, to);
        //配置适配器
        gview.setAdapter(sim_adapter);

        gview.setOnItemClickListener(new AdapterView.OnItemClickListener() {// 为GridView设置项单击事件

            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = null;// 创建Intent对象
                switch (i) {
                    case 0:
                        Intent intent1 = new Intent(MainActivity.this, Memo.class);// 使用 Memo窗口初始化Intent
                        startActivity(intent1);// 打开 Memo
                        break;
                    case 1:
                        Intent intent2 = new Intent(MainActivity.this, FileManager.class);// 使用File窗口初始化Intent
                        startActivity(intent2);// 打开File
                        break;
                    case 2:
                        Intent intent3 = new Intent(MainActivity.this, Schedule.class);// 使用Schedule窗口初始化Intent
                        startActivity(intent3);// 打开Schedule
                        break;
                    case 3:
                        Intent intent0 = new Intent(MainActivity.this, Account.class);// 使用Account窗口初始化Intent
                        startActivity(intent0);// 打开Account
                        break;
                    case 4:
                        Intent intent4 = new Intent(MainActivity.this,User.class);
                        startActivity(intent4);
                        break;
                    case 5:
                        Intent intent5 = new Intent(MainActivity.this,Login.class);
                        startActivity(intent5);
                        finish();
                        break;
                }
            }
        });
        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /*界面图标*/
    //网格对应图标和名字
    public List<Map<String, Object>> getData() {
        for (int i = 0; i < icon.length; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("image", icon[i]);
            map.put("text", iconName[i]);
            data_list.add(map);

        }
        return data_list;
    }

}

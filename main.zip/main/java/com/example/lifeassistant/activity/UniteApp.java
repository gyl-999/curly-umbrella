package com.example.lifeassistant.activity;

import android.app.Application;

import com.example.lifeassistant.dao.AccountDao;
import com.example.lifeassistant.dao.MemoDao;
import com.example.lifeassistant.dao.ScheduleDao;
import com.example.lifeassistant.dao.UserDao;

/* 表示全局应用的类*/
public class UniteApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // 初始化数据库
        AccountDao.initDB(getApplicationContext());
        UserDao.initDB(getApplicationContext());
        MemoDao.initDB(getApplicationContext());
        ScheduleDao.initDB(getApplicationContext());
    }
}

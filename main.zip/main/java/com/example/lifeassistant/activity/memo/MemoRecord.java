package com.example.lifeassistant.activity.memo;


import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.MainActivity;
import com.example.lifeassistant.dao.MemoDao;
import com.example.lifeassistant.model.Tb_Memo;

import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Created by 悦 on 2021/2/20.
 */

public class MemoRecord extends AppCompatActivity implements View.OnClickListener {


    private EditText mr_title,mr_content;
    private Button mr_save,mr_cancel;
    private TextView mr_time;
    Spinner mr_tag;

    Tb_Memo tb_memo = new Tb_Memo();
    String memoId;
    int tag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_record);

        initView();

        //获取从主界面传来的数据
        memoId = getIntent().getStringExtra("data");

        if(memoId!= null){
            mr_title.setText(MemoDao.find(Integer.parseInt(memoId)).getTitle());
            mr_content.setText(MemoDao.find(Integer.parseInt(memoId)).getContent());
            mr_tag.setSelection(MemoDao.find(Integer.parseInt(memoId)).getTag());
        }

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {

        mr_title = findViewById(R.id.mr_title);
        mr_content = findViewById(R.id.mr_content);
        mr_cancel = findViewById(R.id.mr_cancel);
        mr_save = findViewById(R.id.mr_save);
        mr_time = findViewById(R.id.mr_time);
        mr_tag = findViewById(R.id.mr_tag);

        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        mr_cancel.setTypeface(tf);
        mr_save.setTypeface(tf);

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String time = format.format(new Date());
        mr_time.setText(time);

        mr_save.setOnClickListener(this);
        mr_cancel.setOnClickListener(this);

        mr_tag.setOnItemSelectedListener(new selectTag());
    }

    private class selectTag implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            tag = position;
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mr_save:    //保存按钮
                save();
                break;
            case R.id.mr_cancel:  //取消按钮
                mr_content.setText("");
                mr_title.setText("");
                break;
        }
    }



    private void save() {
        String title = mr_title.getText().toString();// 获取便签标题文本框的值
        String content = mr_content.getText().toString();// 获取便签内容文本框的值
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String now_time = format.format(new Date());


            if (!TextUtils.isEmpty(content)||!TextUtils.isEmpty(title)) {// 判断获取的值不为空
                if(memoId != null && MemoDao.find(Integer.parseInt(memoId)).getContent() != null){
                    tb_memo.setId(Integer.parseInt(memoId));
                    tb_memo.setTitle(title);
                    tb_memo.setContent(content);
                    tb_memo.setNow_time(now_time);
                    tb_memo.setTag(tag);
                    tb_memo.setDate_time(now_time);
                    MemoDao.updateMemotb(tb_memo);
                    // 弹出信息提示
                    Toast.makeText(MemoRecord.this, "数据修改成功！", Toast.LENGTH_SHORT).show();
                }else {
                    MemoDao.insertItemToMemotb(new Tb_Memo(0,title,content,now_time,tag,now_time,0));
                    // 弹出信息提示
                    Toast.makeText(MemoRecord.this, "数据保存成功！", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MemoRecord.this, "请输入数据！", Toast.LENGTH_SHORT).show();
            }

    }
}


package com.example.lifeassistant.activity.memo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.example.lifeassistant.R;

import static android.content.Context.NOTIFICATION_SERVICE;


public class AlarmReceiver extends BroadcastReceiver {

    private NotificationManager manager;


    @Override
    public void onReceive(Context context, Intent intent) {


        String title = intent.getExtras().getString("title");
        String content = intent.getExtras().getString("content");
        int id = intent.getExtras().getInt("id");

        manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "memo"; //根据业务执行
            String channelName = "memoName"; //这个是channelid 的解释，在安装的时候会展示给用户看
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            manager.createNotificationChannel(channel);
        }

        //创建一个Notification对象并设置该通知的属性
        Notification notification = new NotificationCompat.Builder(context, "memo")
            //设置打开该通知,该通知自动消失
                .setAutoCancel(true)
            //设置显示在状态栏的提示信息
                .setTicker("您有新的日程")
            //设置通知的图标
                .setSmallIcon(R.drawable.alarm_fs)
            //设置通知内容的标题
                .setContentTitle(title)
            //设置通知内容的内容
                .setContentText(content)
//            //设置通知震动时间,先静止0秒再震动一秒再停止一秒，再震动一秒
//                .setVibrate(new long[]{0,1000,1000,1000})
            //设置使用系统默认的声音，默认的LED灯
                .setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_LIGHTS)
            //设置通知的时间
                .setWhen(System.currentTimeMillis())
            //设置通知将要启动的程序的Intent
                //.setContentIntent(intent)
                .build();
            //使用NotificationManager的notify()方法显示通知
            //第一个参数为每个通知指定一个不同的ID,第二个参数传入Notification的对象
        manager.notify(id, notification);
    }

}

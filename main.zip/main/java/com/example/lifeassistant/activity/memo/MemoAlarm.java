package com.example.lifeassistant.activity.memo;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.MemoDao;
import com.example.lifeassistant.model.Tb_Memo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class MemoAlarm extends AppCompatActivity implements View.OnClickListener, DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private Button ma_save,ma_cancel;
    private EditText ma_title,ma_content;
    private TextView ma_date,ma_time;
    private Button ma_set_date,ma_set_time;
    private TextView ma_now_time;
    Spinner ma_tag;

    Tb_Memo tb_memo = new Tb_Memo();
    String  memoId;

    int kind;
    int tag;

    int year, month,day,hour,minute;

    private DatePickerDialog.OnDateSetListener dateSetListener;
    private TimePickerDialog.OnTimeSetListener timeSetListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_alarm);
        initView();

        //获取从主界面传来的数据
        memoId = getIntent().getStringExtra("data");

        if( memoId!= null){
            ma_title.setText(MemoDao.find(Integer.parseInt(memoId)).getTitle());
            ma_content.setText(MemoDao.find(Integer.parseInt( memoId)).getContent());
            ma_tag.setSelection(MemoDao.find(Integer.parseInt(memoId)).getTag());
            kind = MemoDao.find(Integer.parseInt(memoId)).getKind();

            year = MemoDao.find(Integer.parseInt(memoId)).getYear();
            month = MemoDao.find(Integer.parseInt(memoId)).getMonth();
            day = MemoDao.find(Integer.parseInt(memoId)).getDay();

            hour = MemoDao.find(Integer.parseInt(memoId)).getHour();
            minute = MemoDao.find(Integer.parseInt(memoId)).getMinute();
            ma_date.setText(year + "-" + month +"-" + day);
            ma_time.setText(hour + ":" + minute);
        }

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void initView() {
        ma_save = findViewById(R.id.ma_save);
        ma_cancel = findViewById(R.id.ma_cancel);
        ma_title = findViewById(R.id.ma_titel);
        ma_content = findViewById(R.id.ma_content);
        ma_date = findViewById(R.id.ma_date);
        ma_time = findViewById(R.id.ma_time);
        ma_set_date = findViewById(R.id.ma_set_date);
        ma_set_time = findViewById(R.id.ma_set_time);

        ma_now_time = findViewById(R.id.ma_now_time);
        ma_tag = findViewById(R.id.ma_tag);

        //获取当前时间
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String time = format.format(new Date());
        ma_now_time.setText(time);

        //获取当前时间
        Calendar calendars = Calendar.getInstance();
        calendars.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        year = calendars.get(Calendar.YEAR);
        month = calendars.get(Calendar.MONTH)+1;
        day = calendars.get(Calendar.DAY_OF_MONTH);
        int hour = calendars.get(Calendar.HOUR);
        int min = calendars.get(Calendar.MINUTE);
        time = hour+":"+min;
        //设置为当前时间
        ma_date.setText(year + "-" + month + "-" + day);
        ma_time.setText(time);

        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        ma_cancel.setTypeface(tf);
        ma_save.setTypeface(tf);
        ma_set_date.setTypeface(tf);
        ma_set_time.setTypeface(tf);

        ma_save.setOnClickListener(this);
        ma_cancel.setOnClickListener(this);
        ma_set_date.setOnClickListener(this);
        ma_set_time.setOnClickListener(this);

        ma_tag.setOnItemSelectedListener(new selectTag());
    }

    private class selectTag implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            tag = position;
        }
        @Override
        public void onNothingSelected(AdapterView<?> adapterView) { }
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ma_save:    //保存按钮
                save();
                break;
            case R.id.ma_cancel:  //取消按钮
                ma_content.setText("");
                ma_title.setText("");
                break;
            case R.id.ma_set_date://设置日期
                date();
                break;
            case R.id.ma_set_time://设置时间
                time();
                break;
        }
    }


    //时间
    private void time() {
        Calendar calendar=Calendar.getInstance();
        TimePickerDialog dialog=new TimePickerDialog(this,this,
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
        true);
        dialog.show();
    }

    //日期
    private void date() {
        Calendar calendar=Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dialog = new DatePickerDialog(this,this, year, month, day);
        dialog.show();
    }


    @Override
    public void onDateSet(DatePicker datePicker, int y, int m, int dayOfMonth) {
        String date1 = y + "-" + (m + 1) + "-" +dayOfMonth;
        ma_date.setText(date1);

    }

    @Override
    public void onTimeSet(TimePicker timePicker, int hourOfDay, int min) {
        String temp = "";
        if(hourOfDay<10) temp += "0";
        temp += (hourOfDay+ ":");
        if(min<10) temp += "0";
        temp += min;
        ma_time.setText(temp);
    }


    private void save() {
        String title = ma_title.getText().toString();// 获取标题文本框的值
        String content = ma_content.getText().toString();// 获取内容文本框的值
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String now_time = format.format(new Date());
        String date_time = ma_date.getText().toString()+" "+ma_time.getText().toString();

        if (!TextUtils.isEmpty(content)||!TextUtils.isEmpty(title)) {// 判断获取的值不为空
            if(memoId != null && MemoDao.find(Integer.parseInt(memoId)).getContent() != null){
                tb_memo.setId(Integer.parseInt(memoId));
                tb_memo.setTitle(title);
                tb_memo.setContent(content);
                tb_memo.setNow_time(now_time);
                tb_memo.setTag(tag);
                tb_memo.setDate_time(date_time);
                tb_memo.setKind(1);
                MemoDao.updateMemotb(tb_memo);

                // 弹出信息提示
                Toast.makeText(MemoAlarm.this, "数据修改成功！", Toast.LENGTH_SHORT).show();
                finish();
            }else {
                MemoDao.insertItemToMemotb(new Tb_Memo(0,title,content,now_time,tag,date_time,1));
                // 弹出信息提示
                Toast.makeText(MemoAlarm.this, "数据保存成功！", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            Toast.makeText(MemoAlarm.this, "请输入数据！", Toast.LENGTH_SHORT).show();
        }
    }
}

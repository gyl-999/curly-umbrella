package com.example.lifeassistant.activity.memo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.MainActivity;
import com.example.lifeassistant.dao.MemoDao;
import com.example.lifeassistant.model.Tb_Memo;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;


/**
 * Created by 悦 on 2021/2/2.
 */

public class Memo extends AppCompatActivity{


    private FloatingActionButton memo_add,memo_alarm;
    private ListView memo_lv;
    private GridView memo_grid;
    Spinner memo_tag;
    ImageView memo_mode;
    int tag;
    MemoAdapter adapter;

    private AlarmManager alarmManager;

    private List<Tb_Memo> memoData = new ArrayList<Tb_Memo>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo);

        initView();

        alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);

        adapter = new MemoAdapter(this,memoData);

        queryData();
        queryDatabyTag(tag);

        updateLayout();

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {

        memo_add = findViewById(R.id.memo_add);
        memo_alarm = findViewById(R.id.memo_alarm);

        memo_lv = findViewById(R.id.memo_lv);
        memo_grid = findViewById(R.id.memo_grid);

        memo_tag = findViewById(R.id.memo_tag);
        memo_mode = findViewById(R.id.memo_mode);

        memo_add.setOnClickListener(new addClick());
        memo_alarm.setOnClickListener(new addAlarm());
        memo_mode.setOnClickListener(new setMode());
        memo_tag.setOnItemSelectedListener(new selectTags());
        setLVClickListener();
    }


    private void queryData() {
        memoData.clear();
        memoData.addAll(MemoDao.getMemoList());
//  startAlarms(MemoDao.getMemoList());
        startAlarms(memoData);//添加所有新闹钟
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        queryData();//刷新数据
    }
    //根据点击的类型显示记录
    private void queryDatabyTag(int tag) {
        List<Tb_Memo> list = MemoDao.getMemobyTag(tag);
        memoData.clear();
        memoData.addAll(list);
        adapter.notifyDataSetChanged();
    }


    //设置提醒
    private void startAlarm(Tb_Memo p) {
        Calendar c = p.getPlanTime();

        if(!c.before(Calendar.getInstance())){
            Log.d("he+", "测试测试："+p.getTitle());
            Intent intent = new Intent(Memo.this, AlarmReceiver.class);
            intent.putExtra("title", p.getTitle());
            intent.putExtra("content", p.getContent());
            intent.putExtra("id", (int)p.getId());

            PendingIntent pendingIntent = PendingIntent.getBroadcast(Memo.this, (int) p.getId(), intent, 0);
            //单次提醒
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
        }
    }
    //设置很多提醒
    private void startAlarms(List<Tb_Memo> plans){

        for(Tb_Memo note : plans){
            if(note.getKind()==1)
                startAlarm(note);

        }
    }
    //取消提醒
    private void cancelAlarm(Tb_Memo p) {
        Intent intent = new Intent(Memo.this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(Memo.this, (int)p.getId(), intent, 0);
        alarmManager.cancel(pendingIntent);
    }
    //取消很多提醒
    private void cancelAlarms(List<Tb_Memo> plans){
        Log.d("he", "测试测试测试删除");
        for(Tb_Memo note : plans){
            cancelAlarm(note);
        }
    }

       //设置类型点击事件
    private class selectTags implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            if (position == 0) {  //点击了头布局
                queryData();
            }else {
                int pos = position - 1;
                queryDatabyTag(pos);
            }
        }
        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    }

    public static Boolean isGridView = false;

    private class setMode implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            if (memo_mode.getTag().equals("list"))
            {
                memo_mode.setTag("grid");
                memo_mode.setImageDrawable(getResources().getDrawable(R.drawable.grid));
                memo_grid.setVisibility(View.VISIBLE);
                memo_grid.setAdapter(adapter);
                memo_lv.setVisibility(View.GONE);
                queryData();
                isGridView = true;

            }else {
                memo_mode.setTag("list");
                memo_mode.setImageDrawable(getResources().getDrawable(R.drawable.more));
                memo_lv.setVisibility(View.VISIBLE);
                memo_lv.setAdapter(adapter);
                memo_grid.setVisibility(View.GONE);
                queryData();
                isGridView = false;
            }
        }
    }

    //设置显示模式
    private void updateLayout()
    {
        if (isGridView)
        {
            memo_mode.setTag("grid");
            memo_mode.setImageDrawable(getResources().getDrawable(R.drawable.grid));
            memo_grid.setVisibility(View.VISIBLE);
            memo_grid.setAdapter(adapter);
            memo_lv.setVisibility(View.GONE);
        }
        else
        {
            memo_mode.setTag("list");
            memo_mode.setImageDrawable(getResources().getDrawable(R.drawable.more));
            memo_lv.setVisibility(View.VISIBLE);
            memo_lv.setAdapter(adapter);
            memo_grid.setVisibility(View.GONE);
        }
    }


    //添加普通笔记
    private class addClick implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(Memo.this,MemoRecord.class);
            startActivity(intent);
        }
    }

    //添加定时笔记
    private class addAlarm implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(Memo.this,MemoAlarm.class);
            startActivity(intent);
        }
    }

    /**
     * 设置ListView的事件
     */
    private void setLVClickListener() {
        //ListView的长按事件(删除)
        memo_lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Tb_Memo clickBean = memoData.get(position);  //获取正在被点击的这条信息
                //弹出提示用户是否删除的对话框
                showDeleteItemDialog(clickBean);
                return true;//返回true代表我已经处理这个事件，否则会和单击事件冲突
            }
        });
        memo_grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Tb_Memo clickBean = memoData.get(position);  //获取正在被点击的这条信息
                //弹出提示用户是否删除的对话框
                showDeleteItemDialog(clickBean);
                return true;//返回true代表我已经处理这个事件，否则会和单击事件冲突
            }
        });

        //ListView的点击事件
        memo_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Tb_Memo clickBean = memoData.get(position);
                if(clickBean.getKind()==0){
                    Intent intent = new Intent(Memo.this, MemoRecord.class);  //跳转界面
                    intent.putExtra("data", String.valueOf(clickBean.getId()));
                    startActivityForResult(intent, 1);
                }else if(clickBean.getKind()==1){
                    Intent intent = new Intent(Memo.this, MemoAlarm.class);  //跳转界面
                    intent.putExtra("data", String.valueOf(clickBean.getId()));
                    startActivityForResult(intent, 1);
                }
            }
        });

        memo_grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Tb_Memo clickBean = memoData.get(position);
                if(clickBean.getKind()==0){
                    Intent intent = new Intent(Memo.this, MemoRecord.class);  //跳转界面
                    intent.putExtra("data", String.valueOf(clickBean.getId()));
                    startActivityForResult(intent, 1);
                }else if(clickBean.getKind()==1){
                    Intent intent = new Intent(Memo.this, MemoAlarm.class);  //跳转界面
                    intent.putExtra("data", String.valueOf(clickBean.getId()));
                    startActivityForResult(intent, 1);
                }

            }
        });
    }



    /**
     * 弹出是否删除某一条记录的对话框
     */
    private void showDeleteItemDialog(final Tb_Memo clickBean) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("提示信息").setMessage("您确定要删除这条记录么？"+clickBean.getDate_time())
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int click_id = clickBean.getId();
                        //执行删除的操作
                        MemoDao.deleteItemToMemotbById(click_id);
                        cancelAlarm(clickBean);
                        memoData.remove(clickBean);   //实时刷新，移除集合当中的对象
                        adapter.notifyDataSetChanged();   //提示适配器更新数据
                    }
                });
        builder.create().show();   //显示对话框
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 2 ) {
            //添加完成  做数据的更新
            queryData();
        }
    }

     /*
   【标题栏设置】
    */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.memo_menu_main, menu);
        //设置清空按钮
        MenuItem del = menu.findItem(R.id.mmm_btn_del);
        MenuItem search = menu.findItem(R.id.mmm_btn_search);

        SearchView mSearchView = (SearchView) search.getActionView();
        mSearchView.setQueryHint("Search");
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);//适配器过滤
                return false;
            }
        });

        del.setOnMenuItemClickListener(new MenuItemClickListener());
        return true;
    }

    private class MenuItemClickListener implements MenuItem.OnMenuItemClickListener {
        @Override
        public boolean onMenuItemClick(MenuItem item) {
            showDeleteDialog();
            return false;
        }
    }

    //清空记录
    private void showDeleteDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("删除提示")
                .setMessage("您确定要删除所有记录么？")
                .setPositiveButton("取消",null)
                .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
//                        cancelAlarms(memoData);
                        MemoDao.deleteAllMemo();
                        memoData.clear();   //实时刷新
                        adapter.notifyDataSetChanged();   //提示适配器更新数据
                        Toast.makeText(Memo.this,"删除成功！",Toast.LENGTH_SHORT).show();
                    }

                });
        builder.create().show();
    }


}


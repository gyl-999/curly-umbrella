package com.example.lifeassistant.activity;

import android.content.Intent;
import android.os.Bundle;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.UserDao;

import java.util.logging.Handler;


public class Load extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.load);




        new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    Thread.sleep(3000);//休眠3秒
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Goto();
                /**
                 * 要执行的操作
                 */
            }
        }.start();
    }

    private void Goto() {
        //如果数据库为空
        if (UserDao.getCount() == 0 || UserDao.find().getName().isEmpty() || UserDao.find().getPassword().isEmpty()) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            finish();//销毁此Activity
        } else {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();//销毁此Activity
        }
    }





}

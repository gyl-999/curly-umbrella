package com.example.lifeassistant.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.account.Account;
import com.example.lifeassistant.dao.AccountDao;
import com.example.lifeassistant.dao.MemoDao;
import com.example.lifeassistant.dao.ScheduleDao;
import com.example.lifeassistant.dao.UserDao;

public class User extends AppCompatActivity implements View.OnClickListener {
    private TextView user_name,user_del,user_contect,user_guide;
    private EditText user_pwd;
    private Button user_update;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user);
        //初始化控件
        initView();

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void initView() {

        user_name = findViewById(R.id.user_name);
        user_pwd = findViewById(R.id.user_pwd);
        user_update = findViewById(R.id.user_update);
        user_del = findViewById(R.id.user_del);
        user_contect=findViewById(R.id.user_contact);
        user_guide=findViewById(R.id.user_guide);
        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        user_name.setTypeface(tf);
        user_pwd.setTypeface(tf);
        user_update.setTypeface(tf);
        user_del.setTypeface(tf);
        user_contect.setTypeface(tf);
        user_guide.setTypeface(tf);


        //如果数据库为空
        if (UserDao.getCount() == 0 || UserDao.find().getName().isEmpty()||UserDao.find().getPassword().isEmpty()) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            finish();
            Toast.makeText(this, "请先注册账号", Toast.LENGTH_SHORT).show();
        }else{
            user_name.setText(UserDao.find().getName());//设置用户名
        }
        user_update.setOnClickListener(this);
        user_del.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
      String password = user_pwd.getText().toString().trim();
        switch (view.getId()) {
            case R.id.user_update:    //修改按钮
                if(UserDao.getCount() != 0 || !TextUtils.isEmpty(password)){
                    UserDao.updata(password);
                    Toast.makeText(User.this,"修改成功！",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(User.this,"请输入密码！",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.user_del:    //删除按钮
                UserDelete();
                break;
            case R.id.user_contact:    //请联系我们
                Content();
                break;
            case R.id.user_guide:    //新手指南

                break;
        }
    }

    private void Content() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("联系我们")
                .setMessage("以下是我们的联系方式\nQQ：123456789\n电话：12345678910\n")
                .setNegativeButton("确定", null);
        builder.create().show();
    }

    private void UserDelete() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("删除提示")
                .setMessage("您确定要删除账号么？\n注意：删除后无法恢复，请慎重选择！")
                .setPositiveButton("取消",null)
                .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        AccountDao.deleteAllAccount();//删除记账本数据
                        UserDao.delete();             //删除用户信息
                        MemoDao.deleteAllMemo();      //删除备忘录信息
                        ScheduleDao.deleteAllSchedule();//删除日程表信息
                        ToLogin();
                        Toast.makeText(User.this,"删除成功！",Toast.LENGTH_SHORT).show();
                    }

                });
        builder.create().show();
    }

    private  void ToLogin(){
        Intent intent=new Intent(this,Login.class);
        startActivity(intent);
    }
}

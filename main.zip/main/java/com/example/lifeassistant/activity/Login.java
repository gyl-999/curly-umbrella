package com.example.lifeassistant.activity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.UserDao;
import com.example.lifeassistant.model.Tb_User;

import java.util.ArrayList;


/**
 * Created by 悦 on 2021/2/1.
 */

public class Login extends AppCompatActivity implements View.OnClickListener {

    private TextView txt1;
    private EditText lo_name,lo_pwd;
    private Button lo_log,lo_reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        //初始化控件
        initView();

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        txt1 = findViewById(R.id.txt1);
        lo_name = findViewById(R.id.lo_name);
        lo_pwd = findViewById(R.id.lo_pwd);
        lo_log = findViewById(R.id.lo_login);
        lo_reg = findViewById(R.id.lo_register);

        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        txt1.setTypeface(tf);
        lo_name.setTypeface(tf);
        lo_pwd.setTypeface(tf);
        lo_log.setTypeface(tf);
        lo_reg.setTypeface(tf);

        lo_log.setOnClickListener(this);
        lo_reg.setOnClickListener(this);

        txt1.setOnClickListener(new onClik());
    }
    private class onClik implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            //跳转到主界面
            Intent intent = new Intent(Login.this, MainActivity.class);
            startActivity(intent);
            finish();//销毁此Activity
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.lo_login:    //登录按钮
                String name = lo_name.getText().toString().trim();//消除空格转换为字符串
                String password = lo_pwd.getText().toString().trim();

                //如果数据库为空
                if (UserDao.getCount() == 0 || UserDao.find().getName().isEmpty()||UserDao.find().getPassword().isEmpty()) {
                    Toast.makeText(this, "请先注册账号", Toast.LENGTH_SHORT).show();
                }else {
                    if (!TextUtils.isEmpty(name) || !TextUtils.isEmpty(password)) {//输入框不为空
                        if (name.equals(UserDao.find().getName()) && password.equals(UserDao.find().getPassword())) {//比较
                            Toast.makeText(this, "登录成功", Toast.LENGTH_SHORT).show();
                            //跳转到主界面
                            Intent intent = new Intent(this, MainActivity.class);
                            startActivity(intent);
                            finish();//销毁此Activity
                        } else {
                            Toast.makeText(this, "用户名或密码不正确，请重新输入", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "请输入你的用户名或密码", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case R.id.lo_register:    //注册按钮
                startActivity(new Intent(Login.this,Register.class));
                break;
        }
    }


}

package com.example.lifeassistant.activity.schedule;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import android.widget.ImageView;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;


import com.example.lifeassistant.R;
import com.example.lifeassistant.model.Tb_SchHistory;

import java.util.ArrayList;
import java.util.List;

public class ScheduleHistoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private LayoutInflater inflater;
    private List<Tb_SchHistory> itemList = new ArrayList<>(1);
    private static final int TYPE_TOP = 0x0000;
    private static final int TYPE_NORMAL= 0x0001;

    public ScheduleHistoryAdapter(Context context, List<Tb_SchHistory> itemList) {
        inflater = LayoutInflater.from(context);
        this.itemList = itemList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(inflater.inflate(R.layout.schedule_history_item, parent, false));
    }
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ViewHolder itemHolder = (ViewHolder) holder;
            // 第一行头的竖线不显示
        itemHolder.shi_TopLine.setVisibility(View.INVISIBLE);

        itemHolder.bindHolder(itemList.get(position));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return TYPE_TOP;
        }
        return TYPE_NORMAL;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView shi_AcceptTime, shi_AcceptStation;
        private TextView shi_TopLine, shi_Dot;
        private ImageButton shi_AcceptImg;

        public ViewHolder(View itemView) {
            super(itemView);
            shi_AcceptTime = itemView.findViewById(R.id.shi_Time);
            shi_AcceptStation = itemView.findViewById(R.id.shi_Title);
            shi_TopLine = itemView.findViewById(R.id.shi_TopLine);
            shi_Dot = itemView.findViewById(R.id.shi_Dot);
            shi_AcceptImg = itemView.findViewById(R.id.shi_img);
        }



        public void bindHolder(Tb_SchHistory item) {
            shi_AcceptTime.setText(item.getTime());
            shi_AcceptStation.setText(item.getTitle());

            if(item.getKind()==0){
                shi_AcceptImg.setImageDrawable(shi_AcceptImg.getResources().getDrawable(R.drawable.wancheng));
            }else if(item.getKind()==1){
                shi_AcceptImg.setImageDrawable(shi_AcceptImg.getResources().getDrawable(R.drawable.wancheng_fs));
                }

            }
        }
    }


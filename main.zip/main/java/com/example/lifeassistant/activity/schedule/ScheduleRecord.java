package com.example.lifeassistant.activity.schedule;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.ScheduleDao;
import com.example.lifeassistant.model.Tb_Schedule;


import java.util.Calendar;
import java.util.TimeZone;


public class ScheduleRecord  extends AppCompatActivity implements View.OnClickListener, DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private Button sr_save,sr_cancel;
    private EditText sr_title,sr_content;
    private TextView sr_date,sr_time;
    private Button sr_set_date,sr_set_time;
    private ImageButton sr_img;

    Tb_Schedule tb_schedule = new Tb_Schedule();
    String scheduleId;

    int year, month,day;
    int kind;
    String time;

    private DatePickerDialog.OnDateSetListener dateSetListener;
    private TimePickerDialog.OnTimeSetListener timeSetListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule_record);
        initView();

        //获取从主界面传来的数据
        scheduleId = getIntent().getStringExtra("data");

        if(scheduleId!= null){
            sr_title.setText(ScheduleDao.find(Integer.parseInt(scheduleId)).getTitle());
            sr_content.setText(ScheduleDao.find(Integer.parseInt(scheduleId)).getContent());
            year = ScheduleDao.find(Integer.parseInt(scheduleId)).getYear();
            month = ScheduleDao.find(Integer.parseInt(scheduleId)).getMonth();
            day = ScheduleDao.find(Integer.parseInt(scheduleId)).getDay();
            sr_date.setText(year + "-" + month +"-" + day);
            sr_time.setText(ScheduleDao.find(Integer.parseInt(scheduleId)).getTime());
            kind = ScheduleDao.find(Integer.parseInt(scheduleId)).getKind();

            if(kind == 0){
                sr_img.setImageDrawable(sr_img.getResources().getDrawable(R.drawable.wancheng));
            }else if(kind == 1){
                sr_img.setImageDrawable(sr_img.getResources().getDrawable(R.drawable.wancheng_fs));
            }
        }

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void initView() {
        sr_save = findViewById(R.id.sr_save);
        sr_cancel = findViewById(R.id.sr_cancel);
        sr_title = findViewById(R.id.sr_titel);
        sr_content = findViewById(R.id.sr_content);
        sr_date = findViewById(R.id.sr_date);
        sr_time = findViewById(R.id.sr_time);
        sr_set_date = findViewById(R.id.sr_set_date);
        sr_set_time = findViewById(R.id.sr_set_time);
        sr_img = findViewById(R.id.sr_img);

        Calendar calendars = Calendar.getInstance();
        calendars.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        year = calendars.get(Calendar.YEAR);
        month = calendars.get(Calendar.MONTH)+1;
        day = calendars.get(Calendar.DAY_OF_MONTH);
        int hour = calendars.get(Calendar.HOUR);
        int min = calendars.get(Calendar.MINUTE);
        time = hour+":"+min;
        sr_date.setText(year + "-" + month + "-" + day);//设置为当前时间
        sr_time.setText(time);

        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        sr_cancel.setTypeface(tf);
        sr_save.setTypeface(tf);
        sr_set_date.setTypeface(tf);
        sr_set_time.setTypeface(tf);

        sr_save.setOnClickListener(this);
        sr_cancel.setOnClickListener(this);
        sr_set_date.setOnClickListener(this);
        sr_set_time.setOnClickListener(this);
        sr_img.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.sr_save:    //保存按钮
                save();
                break;
            case R.id.sr_cancel:  //取消按钮
                sr_content.setText("");
                sr_title.setText("");
                break;
            case R.id.sr_set_date:
                date();
                break;
            case R.id.sr_set_time:
                time();
                break;
            case R.id.sr_img:
                changeImag();
                break;
        }
    }


    private void time() {
        Calendar calendar=Calendar.getInstance();
        TimePickerDialog dialog=new TimePickerDialog(this,this,
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
        true);
        dialog.show();
    }

    private void date() {
        Calendar calendar=Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dialog = new DatePickerDialog(this,this, year, month, day);
        dialog.show();
    }

    private void changeImag() {
        if(kind == 0){
            sr_img.setImageDrawable(sr_img.getResources().getDrawable(R.drawable.wancheng_fs));
            kind = 1;
        }else if(kind == 1){
            sr_img.setImageDrawable(sr_img.getResources().getDrawable(R.drawable.wancheng));
            kind = 0;
        }
    }


    @Override
    public void onDateSet(DatePicker datePicker, int y, int m, int dayOfMonth) {
        String date1 = y + "-" + (m + 1) + "-" +dayOfMonth;
        sr_date.setText(date1);
        year=y;
        month=m+1;
        day=dayOfMonth;
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int hourOfDay, int min) {
        String time1 = hourOfDay + ":" +min;
        sr_time.setText(time1);
    }


    private void save() {
        String title = sr_title.getText().toString();// 获取标题文本框的值
        String content = sr_content.getText().toString();// 获取内容文本框的值
        String time = sr_time.getText().toString();

        if (!TextUtils.isEmpty(content)||!TextUtils.isEmpty(title)) {// 判断获取的值不为空
            if(scheduleId != null && ScheduleDao.find(Integer.parseInt(scheduleId)).getContent() != null){
                tb_schedule.setId(Integer.parseInt(scheduleId));
                tb_schedule.setTitle(title);
                tb_schedule.setContent(content);
                tb_schedule.setYear(year);
                tb_schedule.setMonth(month);
                tb_schedule.setDay(day);
                tb_schedule.setTime(time);
                tb_schedule.setKind(kind);
                ScheduleDao.updateScheduletb(tb_schedule);
                // 弹出信息提示
                Toast.makeText(ScheduleRecord.this, "数据修改成功！", Toast.LENGTH_SHORT).show();
                finish();
            }else {
                ScheduleDao.insertScheduletb(new Tb_Schedule(0,title,content,time,year,month,day,kind));
                // 弹出信息提示
                Toast.makeText(ScheduleRecord.this, "数据保存成功！", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            Toast.makeText(ScheduleRecord.this, "请输入数据！", Toast.LENGTH_SHORT).show();
        }

    }



}

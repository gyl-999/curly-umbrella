package com.example.lifeassistant.activity.schedule;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.ScheduleDao;
import com.example.lifeassistant.model.Tb_SchHistory;
import com.example.lifeassistant.model.Tb_Schedule;

import java.util.ArrayList;
import java.util.List;


public class ScheduleHistory extends AppCompatActivity {

    private RecyclerView rvTrace;
    private List<Tb_SchHistory> traceList = new ArrayList<>(10);
    private ScheduleHistoryAdapter adapter;
    public Intent intent_rc = new Intent();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule_history);

        findView();
        initData();
//返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }


    private void findView() {
        rvTrace = findViewById(R.id.sh_RC);
    }

    private void initData() {
        // 模拟一些假的数据
        adapter = new ScheduleHistoryAdapter(this, traceList) ;
        rvTrace.setLayoutManager(new LinearLayoutManager(this));
        rvTrace.setAdapter(adapter);

        final List<Tb_Schedule> list = ScheduleDao.getScheduleList();

        for(int i=0;i<list.size();i++){
            int year = list.get(i).getYear();
            int month = list.get(i).getMonth();
            int day = list.get(i).getDay();
            String time = list.get(i).getTime();
            String fomat_day = year + "年 " + month + "月 " + day + "日" + time;
            traceList.add(new Tb_SchHistory(fomat_day, list.get(i).getTitle(),list.get(i).getKind()));

        }

    }

}

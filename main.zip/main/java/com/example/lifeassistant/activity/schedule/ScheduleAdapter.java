package com.example.lifeassistant.activity.schedule;

import android.content.Context;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.TextView;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.memo.MemoAdapter;
import com.example.lifeassistant.model.Tb_Memo;
import com.example.lifeassistant.model.Tb_Schedule;

import java.util.ArrayList;
import java.util.List;


public class ScheduleAdapter extends BaseAdapter{
    private Context context;//上下文环境

    private List<Tb_Schedule> backList;//用来备份原始数据
    private List<Tb_Schedule> data;//这个数据是会改变的，所以要有个变量来备份一下原始数据
    private MyFilter mFilter;//自定义的过滤器


    public ScheduleAdapter(Context context, List<Tb_Schedule> data) {//传入一个List，用于适配
        this.context = context;
        this.data = data;
        backList = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public List<Tb_Schedule> getScheduleList(){
        return backList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ScheduleAdapter.ViewHoler holer = null;
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.schedule_item,null);
            holer = new ScheduleAdapter.ViewHoler();
            holer.si_title= convertView.findViewById(R.id.si_title);
            holer.si_time = convertView.findViewById(R.id.si_time);
            holer.si_content = convertView.findViewById(R.id.si_content);
            convertView.setTag(holer);
        }else{
            holer = (ScheduleAdapter.ViewHoler) convertView.getTag();
        }


        Tb_Schedule tb_schedule = data.get(position);
        holer.si_title.setText(tb_schedule.getTitle());
        holer.si_time.setText(tb_schedule.getTime());
        holer.si_content.setText(tb_schedule.getContent());

        return convertView;
    }

    class ViewHoler{
        TextView si_title;
        TextView si_content;
        TextView si_time;
        CheckBox si_ach;
    }

    public Filter getFilter() {
        if (mFilter ==null){
            mFilter = new ScheduleAdapter.MyFilter();
        }
        return mFilter;
    }

    class MyFilter extends Filter {
        //我们在performFiltering(CharSequence charSequence)这个方法中定义过滤规则
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            FilterResults result = new FilterResults();
            List<Tb_Schedule> list;
            if (TextUtils.isEmpty(charSequence)) {//当过滤的关键字为空的时候，我们则显示所有的数据
                list = backList;
            } else {//否则把符合条件的数据对象添加到集合中
                list = new ArrayList<>();
                for (Tb_Schedule tb_schedule : backList) {
                    if (tb_schedule.getContent().contains(charSequence)||tb_schedule.getTitle().contains(charSequence)) {
                        list.add(tb_schedule);
                    }
                }
            }
            result.values = list; //将得到的集合保存到FilterResults的value变量中
            result.count = list.size();//将集合的大小保存到FilterResults的count变量中

            return result;
        }
        //在publishResults方法中告诉适配器更新界面
        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            data = (List<Tb_Schedule>) filterResults.values;
            if (filterResults.count>0){
                notifyDataSetChanged();//通知数据发生了改变
            }else {
                notifyDataSetInvalidated();//通知数据失效
            }
        }
    }

}

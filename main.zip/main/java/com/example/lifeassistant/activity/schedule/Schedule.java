package com.example.lifeassistant.activity.schedule;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.MainActivity;
import com.example.lifeassistant.dao.ScheduleDao;
import com.example.lifeassistant.model.Tb_Schedule;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by 悦 on 2021/2/2.
 */

public class Schedule extends AppCompatActivity implements MenuItem.OnMenuItemClickListener {

    private FloatingActionButton sch_add;
    private ListView sch_lv;
    //头布局相关控件
    View headerView;
    CalendarView sch_top_calv;
    private TextView sch_top_nongli;

    ScheduleAdapter adapter;

    private List<Tb_Schedule> scheduleData = new ArrayList<Tb_Schedule>();

    private String select_day;
    int year,month,day;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);

        initView();
        //添加ListView的头布局
        addLVHeaderView();

        adapter = new ScheduleAdapter(this,scheduleData);
        sch_lv.setAdapter(adapter);
        queryData(year,month,day);

        Calendar calendars = Calendar.getInstance();
        calendars.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));

        year = calendars.get(Calendar.YEAR);
        month = calendars.get(Calendar.MONTH);
        day = calendars.get(Calendar.DATE);



        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        sch_add = findViewById(R.id.sch_add);
        sch_lv = findViewById(R.id.sch_lv);

        sch_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//跳转界面，添加笔记
                Intent intent = new Intent(Schedule.this, ScheduleRecord.class);//意图
                startActivity(intent);//启功EditActivity,并获取结果
            }
        });

        setLVClickListener();
    }

    //根据点击的日期显示记录
    private void queryData(int year,int month ,int day) {
        List<Tb_Schedule> list = ScheduleDao.getOneDayFromScheduletb(year,month,day);
        scheduleData.clear();
        scheduleData.addAll(list);
//        startAlarms(scheduleData);//添加所有新闹钟
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {

        super.onResume();
        queryData(year,month ,day);//刷新数据
    }

    /**
     * 给ListView添加头布局的方法
     */
    private void addLVHeaderView() {
        //将布局转换成View对象
        headerView = getLayoutInflater().inflate(R.layout.schedule_top, null);
        sch_lv.addHeaderView(headerView);
        //查找头布局可用控件
        sch_top_calv = headerView.findViewById(R.id.sch_top_calv);
        sch_top_nongli =headerView.findViewById(R.id.sch_top_nongli);

        //从asset 读取字体,得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        sch_top_nongli.setTypeface(tf);

        sch_top_calv.setOnDateChangeListener(new onDate());
    }

    private class onDate implements CalendarView.OnDateChangeListener {
        @Override
        public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
            month = month + 1;
            String day_format = "";
            if (month <= 9) {
                if (dayOfMonth <= 9) {
                    day_format = year + "0" + month + "0" + dayOfMonth;
                } else {
                    day_format = year + "0" + month + dayOfMonth;
                }
            } else {
                if (dayOfMonth <= 9) {
                    day_format = year + "" + month + "0" + dayOfMonth;
                } else {
                    day_format = year + "" + month + dayOfMonth;
                }
            }
            select_day = day_format;

            //农历
            try {
                sch_top_nongli.setText(CalendarUtil.solarToLunar(select_day));
            } catch (Exception e) {
                e.printStackTrace();
            }
            queryData(year,month ,dayOfMonth);
        }
    }

    /**
     * 设置ListView的事件
     */
    private void setLVClickListener() {
        //ListView的长按事件(删除)
        sch_lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {  //点击了头布局
                    return false;
                }
                int pos = position - 1;
                Tb_Schedule clickBean = scheduleData.get(pos);  //获取正在被点击的这条信息

                //弹出提示用户是否删除的对话框
                showDeleteItemDialog(clickBean);
                return true;//返回true代表我已经处理这个事件，否则会和单击事件冲突
            }
        });

        //ListView的点击事件
        sch_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                int pos = position - 1;
                Tb_Schedule clickBean = scheduleData.get(pos);
                Intent intent = new Intent(Schedule.this, ScheduleRecord.class);  //跳转界面
                intent.putExtra("data", String.valueOf(clickBean.getId()));
                startActivityForResult(intent, 1);
            }
        });
    }

    /**
     * 弹出是否删除某一条记录的对话框
     */
    private void showDeleteItemDialog(final Tb_Schedule clickBean) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("提示信息").setMessage("您确定要删除这条记录么？")
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int click_id = clickBean.getId();
                        //执行删除的操作
                        ScheduleDao.deleteItemToScheduletbById(click_id);
                        scheduleData.remove(clickBean);   //实时刷新，移除集合当中的对象
                        adapter.notifyDataSetChanged();   //提示适配器更新数据
                    }
                });
        builder.create().show();   //显示对话框
    }



    /*
   【标题栏设置】
    */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.schedule_menu_main, menu);
        //设置清空按钮
        MenuItem del = menu.findItem(R.id.smm_btn_del);
        MenuItem jilu=menu.findItem(R.id.smm_btn_jilu);
        MenuItem search = menu.findItem(R.id.smm_btn_search);

        SearchView mSearchView = (SearchView) search.getActionView();
        mSearchView.setQueryHint("Search");
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);//适配器过滤
                return false;
            }
        });

        del.setOnMenuItemClickListener(this);
        jilu.setOnMenuItemClickListener(this);
        return true;
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.smm_btn_del:
                showDeleteDialog();
                break;
            case R.id.smm_btn_jilu:
                Intent intent1 = new Intent(Schedule.this, ScheduleHistory.class);
                startActivityForResult(intent1, 0);
                break;
        }
        return false;
    }

    //清空记录
    private void showDeleteDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("删除提示")
                .setMessage("您确定要删除所有记录么？")
                .setPositiveButton("取消",null)
                .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ScheduleDao.deleteAllSchedule();
                        scheduleData.clear();   //实时刷新
                        adapter.notifyDataSetChanged();   //提示适配器更新数据
                        Toast.makeText(Schedule.this,"删除成功！",Toast.LENGTH_SHORT).show();
                    }

                });
        builder.create().show();
    }

}


package com.example.lifeassistant.activity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.UserDao;
import com.example.lifeassistant.model.Tb_User;

/**
 * Created by 悦 on 2021/2/1.
 */

public class Register extends AppCompatActivity implements View.OnClickListener {

    private TextView txt2;
    private EditText re_pwd, re_name, re_pwd_ag, re_pCode;
    private Button re_reg;
    private ImageView re_sCode;

    private String realCode;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        initView();

        //将验证码用图片的形式显示出来
        re_sCode.setImageBitmap(Code.getInstance().createBitmap());
        realCode = Code.getInstance().getCode().toLowerCase();

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        txt2 = findViewById(R.id.txt2);
        re_pwd = findViewById(R.id.re_pwd);
        re_pwd_ag = findViewById(R.id.re_pwd_ag);
        re_name = findViewById(R.id.re_name);
        re_pCode = findViewById(R.id.re_phoneCode);
        re_sCode = findViewById(R.id.re_showCode);
        re_reg = findViewById(R.id.re_register);

        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        txt2.setTypeface(tf);
        re_pwd.setTypeface(tf);
        re_pwd_ag.setTypeface(tf);
        re_name.setTypeface(tf);
        re_pCode.setTypeface(tf);
        re_reg.setTypeface(tf);

        re_sCode.setOnClickListener(this);
        re_reg.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.re_showCode:    //改变随机验证码的生成
                re_sCode.setImageBitmap(Code.getInstance().createBitmap());
                realCode = Code.getInstance().getCode().toLowerCase();
                break;
            case R.id.re_register:    //注册按钮
                //获取用户输入的用户名、密码、验证码
                String username = re_name.getText().toString().trim();
                String password = re_pwd.getText().toString().trim();
                String password2 = re_pwd_ag.getText().toString().trim();
                String phoneCode = re_pCode.getText().toString().toLowerCase();
                //注册验证

                if(UserDao.getCount() == 0) {// 判断数据库中是否已经设置了账号
                    if (!TextUtils.isEmpty(username) && !TextUtils.isEmpty(password) && !TextUtils.isEmpty(phoneCode)) {
                        if (TextUtils.equals(password, password2)) {
                            if (phoneCode.equals(realCode)) {
                                //将用户名和密码加入到数据库中
                                UserDao.add(username, password);
                                Intent intent1 = new Intent(this, MainActivity.class);
                                startActivity(intent1);
                                finish();
                                Toast.makeText(this, "验证通过，注册成功", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(this, "验证码错误,注册失败", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(this, "两次输入的密码不一样", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "请输入账号和密码", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(this, "已有账号，不可重复注册", Toast.LENGTH_SHORT).show();
                    Intent intent2 = new Intent(this, MainActivity.class);
                    startActivity(intent2);
                    finish();
                }

                break;

        }
    }
}

package com.example.lifeassistant.activity.account;

import android.content.DialogInterface;
import android.content.Intent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.account.Adapter.AccountAdapter;
import com.example.lifeassistant.dao.AccountDao;
import com.example.lifeassistant.model.Tb_Account;
import com.example.lifeassistant.activity.account.utils.MoreDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class Account extends AppCompatActivity implements View.OnClickListener {

    ListView todayLv;  //展示今日收支情况的ListView
    private FloatingActionButton moreBtn, editBtn;
    //声明数据源
    List<Tb_Account> mDatas;
    AccountAdapter adapter;
    int year, month, day;
    //头布局相关控件
    View headerView;
    TextView ait_tv1,ait_tv2,ait_tv3;
    TextView ait_month,ait_day;
    ImageView ait_hide;
    TextView ait_out,ait_in,ait_re;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account);

        initTime();
        initView();
        //添加ListView的头布局
        addLVHeaderView();
        mDatas = new ArrayList<>();
        //设置适配器：加载每一行数据到列表当中
        adapter = new AccountAdapter(this, mDatas);
        todayLv.setAdapter(adapter);

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * 初始化自带的View的方法
     */
    private void initView() {
        todayLv = findViewById(R.id.act_lv);
        moreBtn = findViewById(R.id.act_more);
        editBtn = findViewById(R.id.act_edit);

        moreBtn.setOnClickListener(this);
        editBtn.setOnClickListener(this);

        setLVLongClickListener();
    }

    /**
     * 设置ListView的长按事件
     */
    private void setLVLongClickListener() {
        todayLv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {  //点击了头布局
                    return false;
                }
                int pos = position - 1;
                Tb_Account clickBean = mDatas.get(pos);  //获取正在被点击的这条信息

                //弹出提示用户是否删除的对话框
                showDeleteItemDialog(clickBean);
                return false;
            }
        });
    }

    /**
     * 弹出是否删除某一条记录的对话框
     */
    private void showDeleteItemDialog(final Tb_Account clickBean) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("提示信息").setMessage("您确定要删除这条记录么？")
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int click_id = clickBean.getId();
                        //执行删除的操作
                        AccountDao.deleteItemFromAccounttbById(click_id);
                        mDatas.remove(clickBean);   //实时刷新，移除集合当中的对象
                        adapter.notifyDataSetChanged();   //提示适配器更新数据
                        setTopTvShow();   //改变头布局TextView显示的内容
                    }
                });
        builder.create().show();   //显示对话框
    }

    /**
     * 给ListView添加头布局的方法
     */
    private void addLVHeaderView() {
        //将布局转换成View对象
        headerView = getLayoutInflater().inflate(R.layout.account_item_top, null);
        todayLv.addHeaderView(headerView);
        //查找头布局可用控件
        ait_month = headerView.findViewById(R.id.ait_month);
        ait_day = headerView.findViewById(R.id.ait_day);
        ait_hide = headerView.findViewById(R.id.ait_hide);

        ait_tv1 = headerView.findViewById(R.id.ait_tv1);
        ait_tv2 = headerView.findViewById(R.id.ait_tv2);
        ait_tv3 = headerView.findViewById(R.id.ait_tv3);
        ait_in = headerView.findViewById(R.id.ait_in);
        ait_out = headerView.findViewById(R.id.ait_out);
        ait_re = headerView.findViewById(R.id.ait_re);
        //从asset 读取字体
        //得到AssetManager
        AssetManager mgr = getAssets();
        //根据路径得到Typeface
        Typeface tf = Typeface.createFromAsset(mgr, "fonts/Muyao-Softbrush.ttf");
        //设置字体
        ait_month.setTypeface(tf);
        ait_tv1.setTypeface(tf);
        ait_tv2.setTypeface(tf);
        ait_tv3.setTypeface(tf);

        ait_hide.setOnClickListener(new showORhide());
    }

    /* 获取今日的具体时间*/
    private void initTime() {
        Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH) + 1;
        day = calendar.get(Calendar.DAY_OF_MONTH);
    }

    // 当activity获取焦点时，会调用的方法
    @Override
    protected void onResume() {
        super.onResume();
        loadDBData();
        setTopTvShow();
    }

    /* 设置头布局当中文本内容的显示*/
    private void setTopTvShow() {
        ait_month.setText(month + "月");
        //获取本月支出和收入总金额，显示在view当中
        float incomeMonth = AccountDao.getSumMoneyOneMonth(year,month,1);
        float outcomeMonth = AccountDao.getSumMoneyOneMonth(year,month,0);
        float recomeMonth = incomeMonth - outcomeMonth;
        ait_in.setText(incomeMonth+"");
        ait_out.setText(outcomeMonth+"");
        ait_re.setText(recomeMonth+"");
        //获取今日支出和收入总金额，显示在view当中
        float incomeOneDay = AccountDao.getSumMoneyOneDay(year, month, day, 1);
        float outcomeOneDay = AccountDao.getSumMoneyOneDay(year, month, day, 0);
        float recomeOneDay = incomeOneDay - outcomeOneDay;
        String infoOneDay = "今日支出: " + outcomeOneDay + "    收入: " + incomeOneDay + "    余额: "+ recomeOneDay;
        ait_day.setText(infoOneDay);
    }

    //头布局显示或隐藏
    private class showORhide implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            toggleShow();
        }
    }
    boolean isShow = true;
    /**
     * 点击头布局眼睛时，如果原来是明文，就加密，如果是密文，就显示出来
     * */
    private void toggleShow() {
        if (isShow) {   //明文====》密文
            PasswordTransformationMethod passwordMethod = PasswordTransformationMethod.getInstance();
            ait_in.setTransformationMethod(passwordMethod);   //设置隐藏
            ait_out.setTransformationMethod(passwordMethod);   //设置隐藏
            ait_re.setTransformationMethod(passwordMethod);   //设置隐藏
            ait_day.setTransformationMethod(passwordMethod);   //设置隐藏
            ait_hide.setImageResource(R.drawable.hide);
            isShow = false;   //设置标志位为隐藏状态
        }else{  //密文---》明文
            HideReturnsTransformationMethod hideMethod = HideReturnsTransformationMethod.getInstance();
            ait_in.setTransformationMethod(hideMethod);   //设置显示
            ait_out.setTransformationMethod(hideMethod);   //设置显示
            ait_re.setTransformationMethod(hideMethod);   //设置显示
            ait_day.setTransformationMethod(hideMethod);   //设置显示
            ait_hide.setImageResource(R.drawable.show);
            isShow = true;   //设置标志位为隐藏状态
        }
    }

    // 加载数据库数据
    private void loadDBData() {
        List<Tb_Account> list = AccountDao.getAccountListOneDayFromAccounttb(year, month, day);
        mDatas.clear();
        mDatas.addAll(list);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.act_edit:
                Intent it1 = new Intent(this, AccountRecord.class);  //跳转界面
                startActivity(it1);
                break;
            case R.id.act_more:
                MoreDialog moreDialog = new MoreDialog(this);
                moreDialog.show();
                moreDialog.setDialogSize();
                break;
        }
    }

    /*
   【标题栏设置】
    */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.account_menu_main, menu);
        //设置清空按钮
        MenuItem actdel = menu.findItem(R.id.amm_btn_del);
        //按钮点击事件
        actdel.setOnMenuItemClickListener(new MenuItemClickListener());
        return true;
    }
    private class MenuItemClickListener implements MenuItem.OnMenuItemClickListener {
        @Override
        public boolean onMenuItemClick(MenuItem item) {
            showDeleteDialog();
            return false;
        }
    }
    //清空记录
    private void showDeleteDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("删除提示")
                .setMessage("您确定要删除所有记录么？\n注意：删除后无法恢复，请慎重选择！")
                .setPositiveButton("取消",null)
                .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        AccountDao.deleteAllAccount();
                        mDatas.clear();   //实时刷新
                        adapter.notifyDataSetChanged();   //提示适配器更新数据
                        setTopTvShow();   //改变头布局TextView显示的内容
                        Toast.makeText(Account.this,"删除成功！",Toast.LENGTH_SHORT).show();
                    }

                });
        builder.create().show();
    }



}


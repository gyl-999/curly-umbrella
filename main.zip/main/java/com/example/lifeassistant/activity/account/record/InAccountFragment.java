package com.example.lifeassistant.activity.account.record;


import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.AccountDao;
import com.example.lifeassistant.model.Tb_ActType;

import java.util.List;

/**
 * Created by 悦 on 2021/2/23.
 */

public class InAccountFragment extends BaseRecordFragment {


    @Override
    public void loadDataToGV() {
        super.loadDataToGV();
        //获取数据库当中的数据源
        List<Tb_ActType> inlist = AccountDao.getTypeList(1);
        typeList.addAll(inlist);
        adapter.notifyDataSetChanged();
        typeTv.setText("其他");
        typeIv.setImageResource(R.mipmap.in_qt_fs);
    }

    @Override
    public void saveAccountToDB() {
        tb_account.setKind(1);
        AccountDao.insertItemToAccounttb(tb_account);
    }
}


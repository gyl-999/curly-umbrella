package com.example.lifeassistant.activity.account;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.lifeassistant.R;
import com.example.lifeassistant.activity.account.Adapter.ChartVPAdapter;
import com.example.lifeassistant.activity.account.chart.IncomChartFragment;
import com.example.lifeassistant.activity.account.chart.OutcomChartFragment;
import com.example.lifeassistant.dao.AccountDao;
import com.example.lifeassistant.activity.account.utils.CalendarDialog;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AccountChartMonth extends AppCompatActivity {
    Button amc_inBtn,amc_outBtn;
    TextView amc_dateTv,amc_inTv,amc_outTv;
    ViewPager amc_vp;
    int year;
    int month;
    int selectPos = -1,selectMonth =-1;
    List<Fragment>chartFragList;
    private IncomChartFragment incomChartFragment;
    private OutcomChartFragment outcomChartFragment;
    private ChartVPAdapter chartVPAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_chart_month);
        initView();
        initTime();
        initStatistics(year,month);
        initFrag();
        setVPSelectListener();

        //返回键
        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    //返回键
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void setVPSelectListener() {
        amc_vp.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener(){
            @Override
            public void onPageSelected(int position) {
                setButtonStyle(position);
            }
        });
    }

    private void initFrag() {
        chartFragList = new ArrayList<>();
//        添加Fragment的对象
        incomChartFragment = new IncomChartFragment();
        outcomChartFragment = new OutcomChartFragment();
//        添加数据到Fragment当中
        Bundle bundle = new Bundle();
        bundle.putInt("year",year);
        bundle.putInt("month",month);
        incomChartFragment.setArguments(bundle);
        outcomChartFragment.setArguments(bundle);
//        将Fragment添加到数据源当中
        chartFragList.add(outcomChartFragment);
        chartFragList.add(incomChartFragment);
//        使用适配器
        chartVPAdapter = new ChartVPAdapter(getSupportFragmentManager(), chartFragList);
        amc_vp.setAdapter(chartVPAdapter);
//        将Fragment加载到Acitivy当中
    }

    /* 统计某年某月的收支情况数据*/
    private void initStatistics(int year, int month) {
        float inMoneyOneMonth = AccountDao.getSumMoneyOneMonth(year, month, 1);  //收入总钱数
        float outMoneyOneMonth = AccountDao.getSumMoneyOneMonth(year, month, 0); //支出总钱数
        int incountItemOneMonth = AccountDao.getCountItemOneMonth(year, month, 1);  //收入多少笔
        int outcountItemOneMonth = AccountDao.getCountItemOneMonth(year, month, 0); //支出多少笔
        amc_dateTv.setText(year+"年"+month+"月账单");
        amc_inTv.setText("共"+incountItemOneMonth+"笔收入, ￥ "+inMoneyOneMonth);
        amc_outTv.setText("共"+outcountItemOneMonth+"笔支出, ￥ "+outMoneyOneMonth);

    }

    /** 初始化时间的方法*/
    private void initTime() {
        Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH)+1;
    }

    /** 初始化控件*/
    private void initView() {
        amc_inBtn = findViewById(R.id.amc_btn_in);
        amc_outBtn = findViewById(R.id.amc_btn_out);
        amc_dateTv = findViewById(R.id.amc_date);
        amc_inTv = findViewById(R.id.amc_in);
        amc_outTv = findViewById(R.id.amc_out);
        amc_vp = findViewById(R.id.amc_vp);

    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.amc_btn_in:
                setButtonStyle(1);
                amc_vp.setCurrentItem(1);
                break;
            case R.id.amc_btn_out:
                setButtonStyle(0);
                amc_vp.setCurrentItem(0);
                break;
        }
    }


    /* 设置按钮样式的改变  支出-0  收入-1*/
    @SuppressLint("ResourceAsColor")
    private void setButtonStyle(int kind){
        if (kind == 0) {
            amc_outBtn.setBackgroundResource(R.color.blue);
            amc_outBtn.setTextColor(Color.WHITE);
            amc_inBtn.setBackgroundResource(R.color.white);
            amc_inBtn.setTextColor(Color.parseColor("#9F9F9F"));
        }else if (kind == 1){
            amc_inBtn.setBackgroundResource(R.color.blue);
            amc_inBtn.setTextColor(Color.WHITE);
            amc_outBtn.setBackgroundResource(R.color.white);
            amc_outBtn.setTextColor(Color.parseColor("#9F9F9F"));
        }
    }
     /*
   【标题栏设置】
    */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.account_menu_item, menu);
        //设置日历按钮
        MenuItem amt_calendar = menu.findItem(R.id.amt_btn_calendar);
        //按钮点击事件
        amt_calendar.setOnMenuItemClickListener(new AccountChartMonth.MenuItemClickListener());
        return true;
    }
    private class MenuItemClickListener implements MenuItem.OnMenuItemClickListener {
        @Override
        public boolean onMenuItemClick(MenuItem item) {
            showCalendarDialog();
            return false;
        }
    }
    /* 显示日历对话框*/
    private void showCalendarDialog() {
        CalendarDialog dialog = new CalendarDialog(this, selectPos, selectMonth);
        dialog.show();
        dialog.setDialogSize();
        dialog.setOnRefreshListener(new CalendarDialog.OnRefreshListener() {
            @Override
            public void onRefresh(int selPos, int year, int month) {
                AccountChartMonth.this.selectPos = selPos;
                AccountChartMonth.this.selectMonth = month;
                initStatistics(year,month);
                incomChartFragment.setDate(year,month);
                outcomChartFragment.setDate(year,month);
            }
        });
    }

}

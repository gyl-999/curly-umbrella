package com.example.lifeassistant.activity.account.record;


import com.example.lifeassistant.R;
import com.example.lifeassistant.dao.AccountDao;
import com.example.lifeassistant.model.Tb_ActType;

import java.util.List;

/**
 * Created by 悦 on 2021/2/23.
 */

public class OutAccountFragment extends BaseRecordFragment {

    // 重写
    @Override
    public void loadDataToGV() {
        super.loadDataToGV();
        //获取数据库当中的数据源
        List<Tb_ActType> outlist = AccountDao.getTypeList(0);
        typeList.addAll(outlist);
        adapter.notifyDataSetChanged();
        typeTv.setText("其他");
        typeIv.setImageResource(R.mipmap.ic_qita_fs);
    }

    @Override
    public void saveAccountToDB() {
        tb_account.setKind(0);
        AccountDao.insertItemToAccounttb(tb_account);
    }

}

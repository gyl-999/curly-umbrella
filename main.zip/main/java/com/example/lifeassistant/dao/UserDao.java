package com.example.lifeassistant.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.lifeassistant.model.Tb_User;

import java.util.ArrayList;

public class UserDao {

    private static SQLiteDatabase db;
    /* 初始化数据库对象*/
    public static void initDB(Context context){
        DBOpenHelper helper = new DBOpenHelper(context);  //得到帮助类对象
        db = helper.getWritableDatabase();      //得到数据库对象
    }

    /**
     * 添加用户信息
     *增删改查
     */
    public static void add(String name,String password){
        db.execSQL("insert into usertb (name,password) values(?,?)",new Object[]{name,password});
    }
    public static void delete(){
        String sql = "delete from usertb";
        db.execSQL(sql);
    }
    public static void updata(String password){
        db.execSQL("update usertb set password = ?",new Object[]{password});
    }

    /**
     * 查找用户信息
     *
     * @return
     */
    public static Tb_User find() {
        // 查找用户名，密码并存储到Cursor类中
        Cursor cursor = db.rawQuery("select name,password from usertb", null);
        if (cursor.moveToNext()){// 遍历查找到的密码信息
            // 将用户名，密码存储到Tb_User类中
            return new Tb_User(
                    cursor.getString(cursor.getColumnIndex("name")),
                    cursor.getString(cursor.getColumnIndex("password")));
        }
        cursor.close();// 关闭游标
        return null;// 如果没有信息，则返回null
    }


    public static long getCount() {
        Cursor cursor = db.rawQuery("select count(name) from usertb", null);// 获取用户信息的记录数
        if (cursor.moveToNext()){// 判断Cursor中是否有数据
            return cursor.getLong(0);// 返回总记录数
        }
        cursor.close();// 关闭游标
        return 0;// 如果没有数据，则返回0
    }
}

package com.example.lifeassistant.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.lifeassistant.model.Tb_Memo;
import com.example.lifeassistant.model.Tb_Schedule;

import java.util.ArrayList;
import java.util.List;

public class ScheduleDao {
    private static SQLiteDatabase db, dh;

    /* 初始化数据库对象*/
    public static void initDB(Context context) {
        DBOpenHelper helper = new DBOpenHelper(context);  //得到帮助类对象
        db = helper.getWritableDatabase();      //得到数据库对象
        dh = helper.getReadableDatabase();
    }


    /**
     * 获取备忘录信息
     *
     * @return
     */
    public static List<Tb_Schedule> getScheduleList() {
        List<Tb_Schedule> list = new ArrayList<>();
        Cursor cursor = db.query("scheduletb",null,null,null,null,null,"id DESC");

        if(cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Tb_Schedule ScheduleBean = new Tb_Schedule();
                ScheduleBean.setId(cursor.getInt(cursor.getColumnIndex("id")));
                ScheduleBean.setTitle(cursor.getString(cursor.getColumnIndex("title")));
                ScheduleBean.setContent(cursor.getString(cursor.getColumnIndex("content")));
                ScheduleBean.setTime(cursor.getString(cursor.getColumnIndex("time")));
                ScheduleBean.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                ScheduleBean.setMonth(cursor.getInt(cursor.getColumnIndex("month")));
                ScheduleBean.setDay(cursor.getInt(cursor.getColumnIndex("day")));
                ScheduleBean.setKind(cursor.getInt(cursor.getColumnIndex("kind")));
                list.add(ScheduleBean);
            }
        }
        cursor.close();
        return list;
    }


    /*
     * 获取某一天的所有情况
     * */
    public static List<Tb_Schedule>getOneDayFromScheduletb(int year, int month, int day){
        List<Tb_Schedule>list = new ArrayList<>();
        String sql = "select * from scheduletb where year=? and month=? and day=? order by id desc";
        Cursor cursor = db.rawQuery(sql, new String[]{year + "", month + "", day + ""});
        //遍历符合要求的每一行数据
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("id"));
            String title = cursor.getString(cursor.getColumnIndex("title"));
            String content = cursor.getString(cursor.getColumnIndex("content"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            int kind = cursor.getInt(cursor.getColumnIndex("kind"));

            Tb_Schedule Bean = new Tb_Schedule(id, title, content, time, year, month, day,kind);
            list.add(Bean);
        }
        return list;
    }


    /*
     * 向备忘录表当中插入一条元素
     * */
    public static void insertScheduletb(Tb_Schedule tb_schedule){
        ContentValues values = new ContentValues();
        values.put("title",tb_schedule.getTitle());
        values.put("content",tb_schedule.getContent());
        values.put("time",tb_schedule.getTime());
        values.put("year",tb_schedule.getYear());
        values.put("month",tb_schedule.getMonth());
        values.put("day",tb_schedule.getDay());
        values.put("kind",tb_schedule.getKind());
        db.insert("scheduletb",null,values);
    }

    /**
     * 更新备忘录信息
     */
    public static void updateScheduletb(Tb_Schedule tb_schedule){
        ContentValues values = new ContentValues();
        values.put("title", tb_schedule.getTitle());
        values.put("content", tb_schedule.getContent());
        values.put("time", tb_schedule.getTime());
        values.put("year", tb_schedule.getYear());
        values.put("month", tb_schedule.getMonth());
        values.put("day", tb_schedule.getDay());
        values.put("kind",tb_schedule.getKind());
        db.update("scheduletb",values,"id=?",new String[]{ tb_schedule.getId()+""});
    }

    /*
     * 根据传入的id，删除表当中的一条数据
     * */
    public static int deleteItemToScheduletbById(int id){
        int i = db.delete("scheduletb", "id=?", new String[]{id + ""});
        return i;
    }
    /*
     * 删除表格当中的所有数据
     * */
    public static void deleteAllSchedule(){
        String sql = "delete from scheduletb";
        db.execSQL(sql);
    }


    /**
     * 查找便签信息
     *
     * @param id
     * @return
     */
    public static Tb_Schedule find(int id) {

        Cursor cursor = db.rawQuery(
                "select id,title,content,time,year,month,day,kind from scheduletb where id = ?",
                new String[] { String.valueOf(id) });// 根据编号查找信息，并存储到Cursor类中
        if (cursor.moveToNext()){// 遍历查找到的信息
            // 将遍历到的便签信息存储到Tb_flag类中
            return new Tb_Schedule(cursor.getInt(cursor.getColumnIndex("id")),
                    cursor.getString(cursor.getColumnIndex("title")),
                    cursor.getString(cursor.getColumnIndex("content")),
                    cursor.getString(cursor.getColumnIndex("time")),
                    cursor.getInt(cursor.getColumnIndex("year")),
                    cursor.getInt(cursor.getColumnIndex("month")),
                    cursor.getInt(cursor.getColumnIndex("day")),
                    cursor.getInt(cursor.getColumnIndex("kind"))
             );
        }
        cursor.close();// 关闭游标
        return null;// 如果没有信息，则返回null
    }



}

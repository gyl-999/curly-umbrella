package com.example.lifeassistant.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.lifeassistant.model.Tb_Memo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 悦 on 2021/2/20.
 */

public class MemoDao {

    private static SQLiteDatabase db,dh;

    /* 初始化数据库对象*/
    public static void initDB(Context context){
        DBOpenHelper helper = new DBOpenHelper(context);  //得到帮助类对象
        db = helper.getWritableDatabase();      //得到数据库对象
        dh = helper.getReadableDatabase();
    }

    /**
     * 获取备忘录信息
     *
     * @return
     */
    public static List<Tb_Memo> getMemoList() {
        List<Tb_Memo> list = new ArrayList<>();
        Cursor cursor = db.query("memotb",null,null,null,null,null,"id DESC");

        if(cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Tb_Memo MemoBean = new Tb_Memo();
                MemoBean.setId(cursor.getInt(cursor.getColumnIndex("id")));
                MemoBean.setTitle(cursor.getString(cursor.getColumnIndex("title")));
                MemoBean.setContent(cursor.getString(cursor.getColumnIndex("content")));
                MemoBean.setNow_time(cursor.getString(cursor.getColumnIndex("now_time")));
                MemoBean.setTag(cursor.getInt(cursor.getColumnIndex("tag")));
                MemoBean.setDate_time(cursor.getString(cursor.getColumnIndex("date_time")));
                MemoBean.setKind(cursor.getInt(cursor.getColumnIndex("kind")));
                MemoBean.setPTime(MemoBean.getDate_time());
                list.add(MemoBean);
            }
        }
        cursor.close();
        return list;
    }

    /**
     * 获取总记录数
     *
     * @return
     */
    public static long getCount() {
//		db = helper.getWritableDatabase();// 初始化SQLiteDatabase对象
        Cursor cursor = db.rawQuery("select count(id) from memotb", null);// 获取便签信息的记录数
        if (cursor.moveToNext()){// 判断Cursor中是否有数据
            return cursor.getLong(0);// 返回总记录数
        }
        cursor.close();// 关闭游标
        return 0;// 如果没有数据，则返回0
    }

    /*
     * 向备忘录表当中插入一条元素
     * */
    public static void insertItemToMemotb(Tb_Memo tb_memo){
        ContentValues values = new ContentValues();
        values.put("title",tb_memo.getTitle());
        values.put("content",tb_memo.getContent());
        values.put("now_time",tb_memo.getNow_time());
        values.put("tag",tb_memo.getTag());
        values.put("date_time",tb_memo.getDate_time());
        values.put("kind",tb_memo.getKind());
        db.insert("memotb",null,values);
    }


    /*
     * 根据传入的id，删除memotb表当中的一条数据
     * */
    public static int deleteItemToMemotbById(int id){
        int i = db.delete("memotb", "id=?", new String[]{id + ""});
        return i;
    }
    /*
     * 删除memotb表格当中的所有数据
     * */
    public static void deleteAllMemo(){
        String sql = "delete from memotb";
        db.execSQL(sql);
    }

    /**
     * 更新备忘录信息
     */
    public static void updateMemotb(Tb_Memo tb_memo){
        ContentValues values = new ContentValues();
        values.put("title", tb_memo.getTitle());
        values.put("content", tb_memo.getContent());
        values.put("now_time", tb_memo.getNow_time());
        values.put("tag", tb_memo.getTag());
        values.put("date_time",tb_memo.getDate_time());
        values.put("kind",tb_memo.getKind());
        db.update("memotb",values,"id=?",new String[]{ tb_memo.getId()+""});
    }

    /**
     * 查找便签信息
     *
     * @param id
     * @return
     */
    public static Tb_Memo find(int id) {

        Cursor cursor = db.rawQuery(
                "select * from memotb where id = ?",
                new String[] { String.valueOf(id) });// 根据编号查找便签信息，并存储到Cursor类中
        if (cursor.moveToNext()){// 遍历查找到的便签信息
            // 将遍历到的便签信息存储到Tb_flag类中
            return new Tb_Memo(cursor.getInt(cursor.getColumnIndex("id")),
                    cursor.getString(cursor.getColumnIndex("title")),
                    cursor.getString(cursor.getColumnIndex("content")),
                    cursor.getString(cursor.getColumnIndex("now_time")),
                    cursor.getInt(cursor.getColumnIndex("tag")),
                    cursor.getString(cursor.getColumnIndex("date_time")),
                    cursor.getInt(cursor.getColumnIndex("kind")));
        }
        cursor.close();// 关闭游标
        return null;// 如果没有信息，则返回null
    }

    /*
     * 获取某分类的所有情况
     * */
    public static List<Tb_Memo>getMemobyTag(int tag){
        List<Tb_Memo>list = new ArrayList<>();
        String sql = "select * from memotb where tag = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(tag) });
        //遍历符合要求的每一行数据
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("id"));
            String title = cursor.getString(cursor.getColumnIndex("title"));
            String content = cursor.getString(cursor.getColumnIndex("content"));
            String time = cursor.getString(cursor.getColumnIndex("now_time"));
            String date_time = cursor.getString(cursor.getColumnIndex("date_time"));
            int kind = cursor.getInt(cursor.getColumnIndex("kind"));

            Tb_Memo Bean = new Tb_Memo(id, title, content, time, tag, date_time,kind);
            list.add(Bean);
        }
        return list;
    }

    /**
     * 根据kind获取备忘录信息
     *
     * @return
     */
    public static List<Tb_Memo> getMemoByKind(int kind) {
        List<Tb_Memo>list = new ArrayList<>();
        String sql = "select * from memotb where kind = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(kind) });
        //遍历符合要求的每一行数据
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("id"));
            String title = cursor.getString(cursor.getColumnIndex("title"));
            String content = cursor.getString(cursor.getColumnIndex("content"));
            String time = cursor.getString(cursor.getColumnIndex("now_time"));
            String date_time = cursor.getString(cursor.getColumnIndex("date_time"));
            int tag = cursor.getInt(cursor.getColumnIndex("tag"));

            Tb_Memo Bean = new Tb_Memo(id, title, content, time, tag, date_time,kind);
            list.add(Bean);
        }
        return list;
    }

}


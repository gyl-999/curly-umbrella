package com.example.lifeassistant.model;

public class Tb_User {
    private String name;            //用户名
    private String password;        //密码
    public Tb_User(String name, String password) {
        this.name = name;
        this.password = password;
    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    @Override
    public String toString() {
        return "Tb_User{" +
                "name='" + name + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}

package com.example.lifeassistant.model;

public class Tb_SchHistory {

    /** 时间 */
    private String time;
    /** 标题*/
    private String title;

    private int kind;

    public Tb_SchHistory() {
    }

    public Tb_SchHistory(String time, String title, int kind) {
        this.time = time;
        this.title = title;
        this.kind = kind;
    }


    public String getTime() {
        return time;
    }

    public String getTitle() {
        return title;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public int getKind() {
        return kind;
    }

    public void setKind(int kind) {
        this.kind = kind;
    }
}
